import sys
import os

cur_path = os.path.dirname(__file__)
sys.path.append(cur_path)
sys.path.append(os.path.join(cur_path, r'impl'))

from TriggerInterface import TriggerInterface
from impl.VirtualTriggerImpl import VirtualTriggerImpl


class TriggerController(TriggerInterface):

    # # thread lock
    # _instance_lock = threading.Lock()
    #
    # # Singleton
    # def __new__(cls, *args, **kwargs):
    #     if not hasattr(TriggerController, "_instance"):
    #         with TriggerController._instance_lock:
    #             if not hasattr(TriggerController, "_instance"):
    #                 TriggerController._instance = object.__new__(cls)
    #     return TriggerController._instance

    def __init__(self, port, ip='127.0.0.1'):
        """

        :param port: port IO resources
        :param ip: ip address, default: 127.0.0.1
        """
        self._trigger_ctrl = VirtualTriggerImpl(port, ip)

    def open(self) -> bool:
        """
        open the port
        :return: return True/False on success/failure
        """
        return self._trigger_ctrl.open()

    def send(self, event: int) -> bool:
        """
        send trigger with given integer value
        :param event: integer trigger value must in [1, 255]
        :return: return True/False on success/failure
        """
        return self._trigger_ctrl.send(event)

    def close(self) -> bool:
        """
        close the port
        :return: return True/False on success/failure
        """
        return self._trigger_ctrl.close()
