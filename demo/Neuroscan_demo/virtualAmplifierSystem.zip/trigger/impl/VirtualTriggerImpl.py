import socket

from trigger.TriggerInterface import TriggerInterface


class VirtualTriggerImpl(TriggerInterface):

    def __init__(self, port, ip='127.0.0.1'):
        """

        :param port: port IO resources
        :param ip: ip address, default: 127.0.0.1
        """
        if not isinstance(port, int):
            raise TypeError("port type error, input parameter is expected to be an int！")

        # IO resources
        self._port = port

        # ip address, default: 127.0.0.1
        self._ip = ip

        # socket, ipv4, TCP
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def open(self) -> bool:
        """

        :return: return True/False on success/failure
        """
        try:
            self._sock.connect((self._ip, self._port))
            self._sock.setblocking(True)
            self._sock.send(b'trigger')
            return True
        except Exception as e:
            print(e)
            return False

    def send(self, event: int) -> bool:
        """

        :param event: integer trigger value must in [1, 255]
        :return: return True/False on success/failure
        """
        try:
            if not isinstance(event, int):
                raise TypeError("event type error, input parameter is expected to be an int！")
            if event <= 0 or event > 255:
                raise ValueError("event value error, trigger value must in [1, 255]")
            self._sock.send(event.to_bytes(1, 'big'))
            return True
        except Exception as e:
            print(e)
            return False

    def close(self) -> bool:
        """

        :return: return True/False on success/failure
        """
        try:
            self._sock.send(b'None')
            return True
        except Exception as e:
            print(e)
            return False
