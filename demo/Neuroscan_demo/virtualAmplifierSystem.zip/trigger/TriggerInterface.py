from abc import ABCMeta, abstractmethod


class TriggerInterface(metaclass=ABCMeta):

    @abstractmethod
    def open(self) -> bool:
        """
        open the port
        :return: return True/False on success/failure
        """
        pass

    @abstractmethod
    def send(self, event: int) -> bool:
        """
        send trigger with given integer value
        :param event: integer trigger value must in [1, 255]
        :return: return True/False on success/failure
        """
        pass

    @abstractmethod
    def close(self) -> bool:
        """
        close the port
        :return: return True/False on success/failure
        """
        pass
