import time

from trigger.TriggerController import TriggerController

if __name__ == '__main__':
    trigger_controller = TriggerController(12345, '127.0.0.1')
    trigger_controller.open()
    trigger_values = [242, 1, 241, 5, 241, 3, 241, 8, 241]
    for trigger_value in trigger_values:
        trigger_controller.send(trigger_value)
        time.sleep(5)
    trigger_controller.close()
