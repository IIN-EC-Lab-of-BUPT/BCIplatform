import queue
import socket
import struct
import threading
import time

import numpy as np
import select
from loguru import logger

from EEGDataCreator.impl.EEGDataCreatorImpl import EEGDataCreatorImpl
from VirtualAmplifier.VirtualAmplifierInterface import VirtualAmplifierInterface
from VirtualAmplifier.config.VirtualAmplifierConfig import VirtualAmplifierConfig


class VirtualAmplifierImpl(VirtualAmplifierInterface, threading.Thread):

    def __init__(self):
        super().__init__()
        self.serverPort = None
        self.serverHost = None
        self.config = None
        self.dataOffsetMap = None
        self.connectionMap = None
        self.outputIo = None
        self.inputIo = None
        self.running = None
        self.serverSocket = None
        self.logger = None
        self.trigger = None
        self.EEGDataGet = None

    def initial(self):
        self.config = VirtualAmplifierConfig()
        self.serverHost = self.config.serverHost
        self.serverPort = self.config.serverPort
        self.serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.serverSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.serverSocket.setblocking(False)
        self.serverSocket.bind((self.serverHost, self.serverPort))
        self.serverSocket.listen(5)
        self.inputIo = [self.serverSocket]
        self.outputIo = []
        self.connectionMap = {}
        self.running = True
        # 存储每个连接对应的data offset，连接断开后重置
        self.dataOffsetMap = {}
        self.logger = logger

        self.EEGDataGet = EEGDataCreatorImpl()
        self.EEGDataGet.initial()

    def run(self):
        # currect = 0
        while self.running:
            r, w, e = select.select(self.inputIo, self.outputIo, self.inputIo, 0.5)
            self.logger.info("正在监听...{},{},{}",r,w,e)
            # if len(w) == len(self.outputIo):
            #     currect += 1
            for s in r:
                # server socket可读，表示有连接建立请求
                if s is self.serverSocket:
                    client_socket, addr = s.accept()
                    client_socket.setblocking(0)
                    self.inputIo.append(client_socket)
                    if client_socket not in self.outputIo:
                        self.outputIo.append(client_socket)
                        self.logger.info("新建连接。。。")
                    self.connectionMap[client_socket] = addr
                    self.dataOffsetMap[client_socket] = 0
                else:
                    # client断开连接的时候发空包
                    try:
                        data = s.recv(1024)
                        if data == b'':
                            self.disconnect_one(s)
                        elif data == b'trigger':
                            self.outputIo.remove(s)
                            self.logger.info("trigger连接成功。。。")
                        else:
                            self.logger.info("收到trigger{}", data)
                            self.trigger = int().from_bytes(data, 'big')
                    except ConnectionResetError:
                        self.logger.error("ConnectionResetError")
                        self.disconnect_one(s)
            for s in w:
                # 写的时候捕获到异常，也说明对面关连接了
                self.logger.info('生成事件{}的数据', self.trigger)
                data = self.EEGDataGet.get_data(self.trigger)
                try:
                    s.send(data)
                except BrokenPipeError and OSError and KeyError:
                    self.logger.error("BrokenPipeError and OSError and KeyError")
                    self.disconnect_one(s)
            for s in e:
                self.logger.error("handling exception")
                self.disconnect_one(s)
            # (package_length-5)ms一个包
            time.sleep(35 * 0.001)

    def disconnect_one(self, sock):
        if sock is self.serverSocket:
            self.logger.info("virtual acquire server socket closing")
        else:
            self.logger.info("virtual acquire server disconnected with %s" % str(self.connectionMap[sock]))
        if sock in self.outputIo:
            self.outputIo.remove(sock)
        if sock in self.inputIo:
            self.inputIo.remove(sock)
        if sock in self.connectionMap.keys():
            self.connectionMap.pop(sock)
        if sock in self.dataOffsetMap.keys():
            self.dataOffsetMap.pop(sock)
        if sock is not self.serverSocket:
            sock.shutdown(2)
        sock.close()
        self.logger.info("virtual acquire server socket closed")

    def close(self):
        pass

