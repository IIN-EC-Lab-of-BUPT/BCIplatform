import threading
from abc import ABCMeta, abstractmethod


class VirtualAmplifierInterface(metaclass=ABCMeta):

    @abstractmethod
    def initial(self):
        pass

    @abstractmethod
    def run(self):
        pass

    @abstractmethod
    def close(self):
        pass
