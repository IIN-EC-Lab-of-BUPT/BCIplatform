class VirtualAmplifierConfig:
    serverHost = '127.0.0.1'
    serverPort = 12345


