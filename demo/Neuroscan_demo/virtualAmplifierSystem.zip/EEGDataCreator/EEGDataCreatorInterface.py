from abc import ABCMeta, abstractmethod


class EEGDataCreatorInterface(metaclass=ABCMeta):

    @abstractmethod
    def initial(self):
        pass

    @abstractmethod
    def get_data(self, trigger):
        pass

