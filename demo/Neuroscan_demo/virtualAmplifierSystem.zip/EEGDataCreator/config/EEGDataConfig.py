
class EEGDataConfig:

    # 生成数据或者加载本地数据
    # type = "createData"   # 生成数据
    type = "loadData"     # 加载本地数据

    # 数据包长度 单位：s
    timeBuffer = 0.04

    if type == "createData":
        # 采样率
        sampleRate = 250
        # 导联数
        channelNumber = 9
    else:
        # 本地数据路径
        dataPath = "EEGDataCreator/data/block1.pkl"
        # 采样率
        sampleRate = 250
        # 导联数
        channelNumber = 9
