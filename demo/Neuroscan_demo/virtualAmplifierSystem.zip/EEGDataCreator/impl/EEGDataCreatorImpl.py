import os
import pickle
import struct

import numpy as np
from EEGDataCreator.EEGDataCreatorInterface import EEGDataCreatorInterface
from EEGDataCreator.config.EEGDataConfig import EEGDataConfig


class EEGDataCreatorImpl(EEGDataCreatorInterface):
    def __init__(self):
        self.config = None
        self.channelNumber = None
        self.packageLength = None
        self.curTrigger = None
        self.EEGdata = None
        self.curPos = None

        # 加载本地数据时特有
        self.triggerPos = None

    def initial(self):
        self.config = EEGDataConfig()
        self.channelNumber = self.config.channelNumber
        self.packageLength = int(self.config.sampleRate * self.config.timeBuffer)

        if self.config.type == "loadData":
            self.triggerPos = {}
            with open(os.path.join(os.getcwd(), self.config.dataPath), 'rb') as data_f:
                self.EEGdata = pickle.load(data_f)['data']
            triggers = self.EEGdata[-1]
            indexes = np.nonzero(triggers)
            for index in indexes[0]:
                if int(triggers[index]) not in self.triggerPos.keys():
                    self.triggerPos[int(triggers[index])] = []
                self.triggerPos[int(triggers[index])].append(index)

    def get_data(self, trigger):
        if trigger is None:
            data_origin = np.zeros((self.channelNumber, self.packageLength))
        else:
            if trigger != self.curTrigger:
                if self.curTrigger is not None:
                    self.triggerPos[self.curTrigger].remove(self.triggerPos[self.curTrigger][0])
                    if len(self.triggerPos[self.curTrigger]) == 0:
                        self.triggerPos.pop(self.curTrigger)
                self.curPos = self.triggerPos[trigger][0]
                self.curTrigger = trigger
            else:
                self.curPos = self.curPos + self.packageLength
            data_origin = self.EEGdata[:, self.curPos:self.curPos + self.packageLength]

        # data_origin = np.asarray(data_origin, dtype="float32")
        data_unit = data_origin.T.reshape(1, self.channelNumber * self.packageLength).tolist()[0]
        format = '<' + (str(self.channelNumber) + 'f') * self.packageLength
        return struct.pack(format, *data_unit)
