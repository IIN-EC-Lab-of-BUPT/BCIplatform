from VirtualAmplifier.impl.VirtualAmplifierImpl import VirtualAmplifierImpl

if __name__ == '__main__':

    va = VirtualAmplifierImpl()
    va.initial()
    va.start()

    print(111)